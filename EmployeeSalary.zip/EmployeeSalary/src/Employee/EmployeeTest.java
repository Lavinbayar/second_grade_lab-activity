
package Employee;


public class EmployeeTest {
    public static void main(String[] args) {
        
     
    Employee E1=new Employee("Lavin","Bayar",2222);
     Employee E2=new Employee("Lana","Akram",2222);
             System.out.println("NAME\t\tYEARLY SALARY");
    E1.display();
   
    E2.display();
    
        System.out.println("  10 percent salary raised!! Yoohooo!");
        E1.risesalary(0);
        E2.risesalary(0);
         System.out.println("NAME\t\tYEARLY SALARY");
  
  
    E1.display();
    E2.display();
    
    }
}
