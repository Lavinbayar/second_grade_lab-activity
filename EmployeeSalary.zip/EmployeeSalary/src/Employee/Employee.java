
package Employee;


public class Employee {
    
    private String firstname;
    private String lastname;
    private double salary;
    
    public Employee(String firstname,String lastname,double salary ){
        this.firstname=firstname;
        this.lastname=lastname;
       
        if(salary>0)
             this.salary=salary;
    }
  
    public void setfirstname(String firstname){
        this.firstname=firstname;
    }
    
    public void setlastname(String lastname){
        this.lastname=lastname;
    }
    public void setsalary(double salary){
         if(salary>0)
        this.salary=salary;
        
    }
    
    
    public String getfirstname(){
        return firstname;
    }
     public String getlastname(){
        return lastname;
     }
     public double getsalary(){
        return salary;
         }
         
     
     
     public double yearlysalary(){
         return salary*12;
     }
     public void risesalary(double percent){
         salary+=salary*0.10;
     }
         
         public void display(){
            
             System.out.println(getfirstname()+"  "+getlastname()+"     "+"  $"+getsalary());
             
         }
}
    
    
    
    
    
    
    
    
