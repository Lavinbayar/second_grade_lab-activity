/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shapes;

public class main {
    
     public static void main(String []args){
         
         
    square q=new square();
    
    q.setname("ee");
    q.setcolor("red");
    q.setlength(4);
    q.setarea();
    q.display();
         
         
         
         
    
    
     }
}
