/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shapes;


public class Shape {
    private String name;
    private String color;
    private double length;
    
   /* public Shape(String name,String color,double length){
        this.color=color ; 
       this.length=length;
       this.name=name;
    }*/
    public void setname(String name){
    
    this.name=name;
    }
    public void setcolor(String color){
        this.color=color;
    }
    public void setlength(double length){
        this.length=length;
    }
    
    public String getcolor(){
        return color;
    }
     public String getname(){
        return name;
    }
    public double getlength(){
        return length;
    }
 public void display(){
     System.out.println("name"+getname());
     System.out.println("color"+getcolor());
     System.out.println("length"+getlength());
 }
}
