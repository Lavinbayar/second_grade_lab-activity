/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shapes;


public class cube extends square {
     private double area;
    private double parameter;
    
    public void setarea(double area){
        this.area=6*super.getlength()*super.getlength();
        
    }
     public void setparameter(double parameter){
        this.parameter=12*super.getlength();
        
    }
    public double getarea(){
        return area;}
     public double getparameter(){
        return parameter;}
    
    public void dsiplay(){
        super.display();
        System.out.println("cube area"+getarea());
        System.out.println("cube parameter"+getparameter());
    }
    
}

