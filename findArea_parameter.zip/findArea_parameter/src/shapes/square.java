
package shapes;


public class square extends Shape {
    private double area;
    private double parameter;
    
 public void setarea(double area){
     this.area=2*super.getlength();
     
 }
    public double getarea(){
       return area;
        
    }
     public  void setparameter (double parameter){
        this.parameter=4*super.getlength();
     }
    public double getparameter(){
       return parameter;
    }
   public void dsiplay(){
       super.display();
       
        System.out.println("square area"+getarea());
        System.out.println("square parameter"+getparameter());
    }

 
    }
    
    
   
  
    
    
    
    
    
    

