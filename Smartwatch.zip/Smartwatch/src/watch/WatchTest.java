
package watch;

import java.util.Scanner;

public class WatchTest {
    public static void main(String args[]){
    Scanner input=new Scanner(System.in);
      
    Watch  h=new Watch(2,2,2);
    h.display();
     Watch h1=new Watch(0,0,0);
     Watch h2=new Watch(12,3,0);
      Watch h3=new Watch(1,0,0);
        System.out.println("change hour");
   int  hour=input.nextInt();
   h.sethour(hour);
   
        System.out.println("change minute");
   int minute=input.nextInt();
   h.setminute(minute);
   
        System.out.println("change second");
   int second =input.nextInt();
   h.setsecond(second);
   
  h.display();
    
      
    
    }
    
    
}
