
package account;


public class Account {
    private  int id ;
    private double balance;
    
    public Account(int id,double balance){
        this.id=id;
     this.balance=balance; 
     if(balance>0){
       this.balance=balance;  
     }
     else{  
     this.balance=0;
    
    }
    }
    public int getid(){
        return id;
    }
    public double getbalance(){
        return balance;
    }
    public void setDesposite(double Desposite){
        if(Desposite>0){
            balance+=Desposite;
            
        }
    }
    public void setDebit(double Debit){
        if(Debit>balance){
            System.out.println("Debit amount exceeded account balance ");
        }else{
           balance-=Debit; 
    }
    }}
    

    
