
package account;


public class AcountTest {
    public static void main(String args[]){
    Account A1=new Account(11,800);
     Account A2=new Account(122,900);
    
        System.out.println("A1 balance "+A1.getbalance());
    System.out.println("A2 balance "+A2.getbalance());
    
    A1.setDesposite(70);
    A2.setDebit(60);
    
     System.out.println("A1 balance "+A1.getbalance());
    System.out.println("A2 balance "+A2.getbalance());
}
}