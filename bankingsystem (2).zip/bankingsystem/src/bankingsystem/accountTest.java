
package bankingsystem;

import java.util.Scanner;

public class accountTest {
    
    public static void main(String args[]){
    
    Scanner input=new Scanner(System.in);
    account  obj1=new account();
    
        System.out.println("enter your account number");
    int number=input.nextInt();
    obj1.setaccountNumber(number);
    
    obj1.setbalance(1000);
    
        System.out.println("account number"+obj1.getaccountNumber());
        System.out.println("Balance:"+obj1.getbalance());
    
        System.out.println("Enter amount to debit: ");
    double  Debit=input.nextInt();
        
        obj1.setdebit(Debit);
        System.out.println("your balance now:"+obj1.getbalance());
        
}
}