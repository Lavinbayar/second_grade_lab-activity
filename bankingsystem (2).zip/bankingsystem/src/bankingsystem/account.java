
package bankingsystem;


public class account {
    
    private int accountNumber;
    private double balance;
    
    public void setaccountNumber(int acc){
        accountNumber=acc;
    }
    public void setbalance(double B){
        balance=B;
    }
    
    public int getaccountNumber(){
        return accountNumber;
    }
    public double getbalance(){
        return balance;
    }
    
    public void setdebit(double Debit){
        if(Debit <=balance){
             balance=getbalance()-Debit;
        }
        else {
            System.out.println("Debit amount exceeded account balance");
        }
    }
    
    
   
    
    
    
    
    
    
    
    
    
    
    
}
