
package studentt;

public class studentTest {
    public static void main(String args[]){
    
    student s=new student(1,"lavin",1);
   
    s.increment();
    s.display();
        System.out.println("********************************");
    student s2=new student(2,"shaz",1);
   
    s2.increment();
     s2.display();
    }
 
}