
package studentt;


public class student {
    private int  ID;
    private final String Dep="CE";
    private String name;
    private  int semester;
    
    public student(int ID,String name,int semester ){
        this.ID=ID;
        this.name=name;
        this.semester=semester;
    }
    public void setID(int ID){
        this.ID=ID;
    }
    public void setname(String name){
        this.name=name;
}

    public void setsemester(int semester){
        this.semester=semester;
    }

public int getID(){
return ID;
}
public String  getname(){
   return name; 
}
public int getsemester(){
    return semester;
}
public String getDep(){
    return Dep;
}

public void display(){
    System.out.println("name :"+getname());
    System.out.println("ID :"+getID());
    System.out.println("semester :"+getsemester());
    System.out.println("Department: "+getDep());
}
public void increment(){
    semester++;
}
}
