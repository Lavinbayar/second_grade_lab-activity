/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package desktopinfo;

public class desktop {
    private String brand;
    private String  processor;
    private int ramsize;
    
    public void setbrand(String B){
        brand=B;
    }
    public void setprocessor(String p){
        processor=p;
    }
    public void setramsize(int r ){
        ramsize=r;
    }
     
    
    public String getbrand(){
        return brand;
    }
    public String getprocessor(){
        return processor;
    }
    public int getramsize(){
        return ramsize;        
        
    }
    public void setupgrade(int up){
        ramsize=getramsize()+up;
    }
    
    
}
