
package desktopinfo;

import java.util.Scanner;


public class main {
    public static void main(String args[]){
    Scanner input=new Scanner(System.in);
        
        desktop obj=new desktop();
        
        obj.setbrand("Dell");
        obj.setprocessor("intel core i7");
        obj.setramsize(16);
        
        System.out.println("brand:"+obj.getbrand());
        System.out.println("processor"+obj.getprocessor());
        System.out.println("ramsize:"+obj.getramsize());
        
        System.out.println("enter how many GB you want to add to RAM");
        int upgrade=input.nextInt();
        
        obj.setupgrade(upgrade);
        
        System.out.println("now your ramsize:"+obj.getramsize()+"GB") ;
        
    }
}
